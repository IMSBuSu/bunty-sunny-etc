package org.ims.ignou.view.course.add;

public class TestView {

	public static void main(String[] args) {

		
		CourseView courseView=new CourseView();
		courseView.setVisible(true);
	}

}
