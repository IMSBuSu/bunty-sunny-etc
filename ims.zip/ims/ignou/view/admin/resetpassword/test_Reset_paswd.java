package org.ims.ignou.view.admin.resetpassword;

public class test_Reset_paswd {
	public static void main(String[] args) 
	{
		
		Reset_paswd paswd=new Reset_paswd();
		paswd.setVisible(true);
	}

}
