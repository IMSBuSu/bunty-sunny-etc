package org.ims.ignou.view.admin.signup;

import org.ims.ignou.view.extendable.Registration;

public class Signup extends Registration
{	
	public Signup()
	{
		setTitle("Sign Up");		
	}
}
