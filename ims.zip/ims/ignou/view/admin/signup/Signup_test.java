package org.ims.ignou.view.admin.signup;

public class Signup_test 
{
	public static void main(String[] args) 
	{
			Signup signup=new Signup();
			signup.setVisible(true);
	}
}
