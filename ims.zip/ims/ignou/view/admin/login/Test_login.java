package org.ims.ignou.view.admin.login;

public class Test_login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login login=new Login();
		login.setVisible(true);
	}
}
