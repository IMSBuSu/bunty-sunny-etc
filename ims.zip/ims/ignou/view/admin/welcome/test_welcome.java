package org.ims.ignou.view.admin.welcome;

import javax.swing.JColorChooser;

public class test_welcome 
{	
	public static void main(String[] args)
	{		
			Welcome welcome=new Welcome();		
			welcome.setVisible(true);				
	}		
}


