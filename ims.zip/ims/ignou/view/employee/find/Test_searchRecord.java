package org.ims.ignou.view.employee.find;

public class Test_searchRecord {

	public static void main(String args[]){
		SearchRecord record=new SearchRecord();
		record.setVisible(true);
	}

}
