package org.ims.ignou.view.extendable;

public class Test_registration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Registration student=new Registration();
		student.setVisible(true);
	}

}
